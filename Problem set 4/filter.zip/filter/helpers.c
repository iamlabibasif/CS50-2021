#include "helpers.h"
#include <math.h>

// Convert image to grayscale
void grayscale(int height, int width, RGBTRIPLE image[height][width])
{
    int Red = 0;
    int Blue = 0;
    int Green = 0;
    double average = 0;

    for (int i = 0; i < height; i++)
    {
        for (int j = 0; j < width; j++)
        {
            Red = image[i][j].rgbtRed;
            Green = image[i][j].rgbtGreen;
            Blue = image[i][j].rgbtBlue;

            average = round((Red + Blue + Green) / 3.0);

            image[i][j].rgbtRed = average;
            image[i][j].rgbtGreen =  average;
            image[i][j].rgbtBlue = average;
        }
    }
    return;
}

// Reflect image horizontally
void reflect(int height, int width, RGBTRIPLE image[height][width])
{
    int Red = 0;
    int Blue = 0;
    int Green = 0;
    int Red1 = 0;
    int Blue1 = 0;
    int Green1 = 0;
    int count = 0;

    if (width % 2 == 0)
    {
        count = width / 2;
    }

    else
    {
        count = round(width / 2.0);
        count = count - 1;
    }

    for (int i = 0; i < height; i++)
    {
        for (int j = 0; j < count; j++)
        {
            Red = image[i][j].rgbtRed;
            Green = image[i][j].rgbtGreen;
            Blue = image[i][j].rgbtBlue;

            image[i][j].rgbtRed = image[i][(width - j) - 1].rgbtRed;
            image[i][j].rgbtGreen = image[i][(width - j) - 1].rgbtGreen;
            image[i][j].rgbtBlue = image[i][(width - j) - 1].rgbtBlue;

            image[i][(width - j) - 1].rgbtRed = Red;
            image[i][(width - j) - 1].rgbtGreen = Green;
            image[i][(width - j) - 1].rgbtBlue = Blue;
        }
    }
    return;
}

// Blur image
void blur(int height, int width, RGBTRIPLE image[height][width])
{
    RGBTRIPLE image2[height][width];

    int Red;
    int Blue;
    int Green;
    float count;

    for (int i = 0; i < height; i++)
    {
        for (int j = 0; j < width; j++)
        {
            count = 0.0;
            Red = 0;
            Blue = 0;
            Green = 0;

            for (int k = i - 1; k <= i + 1; k++)
            {
                for (int l = j - 1; l <= j + 1; l++)
                {
                    if (k >= 0 && k < height && l >= 0 && l < width)
                    {
                        Red = Red + image[k][l].rgbtRed;
                        Green = Green + image[k][l].rgbtGreen;
                        Blue = Blue + image[k][l].rgbtBlue;
                        count++;
                    }
                }
            }

            image2[i][j].rgbtRed = round(Red / count);
            image2[i][j].rgbtGreen = round(Green / count);
            image2[i][j].rgbtBlue = round(Blue / count);
        }
    }

    for (int i = 0; i < height; i++)
    {
        for (int j = 0; j < width; j++)
        {
            image[i][j].rgbtRed = image2[i][j].rgbtRed;
            image[i][j].rgbtBlue = image2[i][j].rgbtBlue;
            image[i][j].rgbtGreen = image2[i][j].rgbtGreen;
        }
    }
    return;
}

// Detect edges
void edges(int height, int width, RGBTRIPLE image[height][width])
{
    RGBTRIPLE image2[height][width];

    int x [] = {-1, 0, 1, -2, 0, 2, -1, 0, 1};
    int y [] = {-1, -2, -1, 0, 0, 0, 1, 2, 1};

    int Redx;
    int Redy;
    int Bluex;
    int Bluey;
    int Greenx;
    int Greeny;
    int Red;
    int Green;
    int Blue;
    int count;

    for (int i = 0; i < height; i++)
    {
        for (int j = 0; j < width; j++)
        {
            count = 0;
            Redx = 0;
            Bluex = 0;
            Greenx = 0;
            Redy = 0;
            Bluey = 0;
            Greeny = 0;

            for (int k = i - 1; k <= i + 1; k++)
            {
                for (int l = j - 1; l <= j + 1; l++)
                {
                    if (k >= 0 && k < height && l >= 0 && l < width)
                    {
                        Redx = Redx + (image[k][l].rgbtRed * x[count]);
                        Redy = Redy + (image[k][l].rgbtRed * y[count]);
                        Greenx = Greenx + (image[k][l].rgbtGreen * x[count]);
                        Greeny = Greeny + (image[k][l].rgbtGreen * y[count]);
                        Bluex = Bluex + (image[k][l].rgbtBlue * x[count]);
                        Bluey = Bluey + (image[k][l].rgbtBlue * y[count]);
                    }
                    count++;
                }
            }

            Red = round(sqrt((Redx * Redx) + (Redy * Redy)));
            Green = round(sqrt((Greenx * Greenx) + (Greeny * Greeny)));
            Blue = round(sqrt((Bluex * Bluex) + (Bluey * Bluey)));

            if (Red > 255)
            {
                Red = 255;
            }

            if (Blue > 255)
            {
                Blue = 255;
            }

            if (Green > 255)
            {
                Green = 255;
            }

            image2[i][j].rgbtRed = Red;
            image2[i][j].rgbtGreen = Green;
            image2[i][j].rgbtBlue = Blue;
        }
    }


    for (int i = 0; i < height; i++)
    {
        for (int j = 0; j < width; j++)
        {
            image[i][j].rgbtRed = image2[i][j].rgbtRed;
            image[i][j].rgbtBlue = image2[i][j].rgbtBlue;
            image[i][j].rgbtGreen = image2[i][j].rgbtGreen;
        }
    }

    return;
}











